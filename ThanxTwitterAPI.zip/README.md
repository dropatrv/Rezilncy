# ThanxTwitterAPI
Node(Express) + Angular2 application for searching Twitter tweets
