"use strict";
var Tweet = (function () {
    function Tweet() {
    }
    return Tweet;
}());
exports.Tweet = Tweet;
var Status = (function () {
    function Status() {
    }
    return Status;
}());
exports.Status = Status;
//# sourceMappingURL=tweet.model.js.map